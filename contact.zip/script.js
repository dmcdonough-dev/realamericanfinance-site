function calculateScore() {
    document.getElementById('result').innerText = 'Your financial health score: 75/100 - Keep grinding!';
}